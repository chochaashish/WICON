<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/
Auth::routes();

Route::get('/', 'PageController@home');
Route::get('/home', 'PageController@home');
Route::get('/about', 'PageController@about');
Route::get('/menu', 'PageController@menu');
Route::get('/contact', 'PageController@contact');

//Route::get('/logout', function () {
//	Auth::logout();
  //  return view('home');
//});

Route::get('/admin','PageController@admin');
Route::get('/base','PageController@base');

Route::get('/insert','ItemsController@insertform')->middleware('AuthCheck');
Route::post('create','ItemsController@insert');

Route::get('view-items','ItemsController@index');

Route::get('edit-items','ItemsController@editform'); 
Route::get('edit/{id}','ItemsController@newval'); 
Route::post('edit/{id}','ItemsController@edit'); 

Route::get('delete-items','ItemsController@deleteform'); 
Route::get('delete/{id}','ItemsController@destroy');

//Route::get('/home', 'HomeController@index');
