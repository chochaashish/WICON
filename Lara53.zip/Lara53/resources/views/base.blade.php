@extends('layouts.app')

@section('title')
Base
@endsection

@section('content')
<div class='row'>
	<div class='col-md-6 col-md-offset-3'> 
		<div class='panel panel-default'>
			<div class='panel-body text-center'>
				<p><a href='/insert'><button class='btn btn-success'>Add Items</button></a></p>
				<p><a href='/view-items'><button class='btn btn-success'>View Items</button></a></p>
				<p><a href='/edit-items'><button class='btn btn-success'>Update Items</button></a></p>
				<p><a href='/delete-items'><button class='btn btn-success'>Delete Items</button></a></p>	
			</div>
		</div>
	</div>
</div>
@endsection