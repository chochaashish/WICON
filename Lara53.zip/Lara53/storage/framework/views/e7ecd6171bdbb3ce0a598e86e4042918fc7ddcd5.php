<?php $__env->startSection('title'); ?>
Base
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class='row'>
	<div class='col-md-6 col-md-offset-3'> 
		<div class='panel panel-default'>
			<div class='panel-body text-center'>
				<p><a href='/insert'><button class='btn btn-success'>Add Items</button></a></p>
				<p><a href='/view-items'><button class='btn btn-success'>View Items</button></a></p>
				<p><a href='/edit-items'><button class='btn btn-success'>Update Items</button></a></p>
				<p><a href='/delete-items'><button class='btn btn-success'>Delete Items</button></a></p>	
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>